# generated from colcon_core/shell/template/command_prefix.sh.em
. "/home/ishabh/interbotix_ws/install/interbotix_moveit_interface_msgs/share/interbotix_moveit_interface_msgs/package.sh"
. "/home/ishabh/interbotix_ws/install/moveit_visual_tools/share/moveit_visual_tools/package.sh"
